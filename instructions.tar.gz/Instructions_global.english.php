<?php
$txt['instructions'] = 'Instructions';
$txt['instructions_new'] = 'New Instruction';

$txt['permissiongroup_instructions'] = 'Instructions';
$txt['permissiongroup_simple_instructions'] = 'Instructions';
$txt['permissionname_inst_can_delete'] = 'Allowed to delete instructions:';
$txt['permissionname_inst_can_view_published'] = 'Allowed to view <b>published</b> instructions:';
$txt['permissionname_inst_can_view_unpublished'] = 'Allowed to view <b>unpublished</b> instructions:';
$txt['permissionname_inst_can_edit'] = 'Allowed to edit instructions:';
$txt['permissionname_inst_can_delete_own'] = 'Own instruction';
$txt['permissionname_inst_can_delete_any'] = 'Any instruction';
$txt['permissionname_inst_can_view_unpublished_own'] = 'Own instruction';
$txt['permissionname_inst_can_view_unpublished_any'] = 'Any instruction';
$txt['permissionname_inst_can_edit_own'] = 'Own instruction';
$txt['permissionname_inst_can_edit_any'] = 'Any instruction';
$txt['permissionname_inst_publish_instruction'] = 'Allowed to post instructions';

?>